#include <iostream>
#include <unordered_set>
int main() {
    long long tmp;
    std::unordered_set<long long> hashset;
    while (std::cin >> tmp) hashset.insert(tmp);
}
